from fastapi import FastAPI, HTTPException
from typing import List
from github_tools.repo_scraper import RepositoryScraper
from github_tools.repo_finder import RepositoryFinder
from github_tools.resume_checker import ResumeChecker

app = FastAPI(title="Gitify Tools API")

@app.get("/top-repos/")
async def get_top_repos(language: str = None, limit: int = 10):
    scraper = RepositoryScraper()
    return await scraper.get_top_repositories(language, limit)

@app.get("/find-repos/")
async def find_repos_by_tags(tags: List[str], limit: int = 10):
    finder = RepositoryFinder()
    return await finder.find_repositories_by_tags(tags, limit)

@app.get("/check-contributions/{username}/{repo_name}")
async def check_contributions(username: str, repo_name: str):
    checker = ResumeChecker()
    result = await checker.get_user_contributions(username, repo_name)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result