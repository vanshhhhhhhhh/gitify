import pytest
from github_tools.repo_finder import RepositoryFinder

@pytest.mark.asyncio
async def test_find_repositories_by_tags():
    finder = RepositoryFinder()
    repos = await finder.find_repositories_by_tags(['help wanted'], limit=5)
    assert len(repos) <= 5
    assert all('repo_name' in repo for repo in repos)