import pytest
from github_tools.resume_checker import ResumeChecker

@pytest.mark.asyncio
async def test_get_user_contributions():
    checker = ResumeChecker()
    contributions = await checker.get_user_contributions('octocat', 'octocat/Hello-World')
    assert 'total_commits' in contributions
    assert 'total_prs' in contributions
    assert 'total_issues' in contributions