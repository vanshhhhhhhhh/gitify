import pytest
from github_tools.repo_scraper import RepositoryScraper

@pytest.mark.asyncio
async def test_get_top_repositories():
    scraper = RepositoryScraper()
    repos = await scraper.get_top_repositories(limit=5)
    assert len(repos) == 5
    assert all('name' in repo for repo in repos)