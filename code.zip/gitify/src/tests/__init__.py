"""
Test suite for Gitify
"""

import pytest