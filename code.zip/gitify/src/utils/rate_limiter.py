from github import Github
from .config import GITHUB_TOKEN

def check_rate_limit():
    g = Github(GITHUB_TOKEN)
    rate_limit = g.get_rate_limit()
    return {
        "core": {
            "remaining": rate_limit.core.remaining,
            "limit": rate_limit.core.limit,
            "reset_time": rate_limit.core.reset.isoformat()
        },
        "search": {
            "remaining": rate_limit.search.remaining,
            "limit": rate_limit.search.limit,
            "reset_time": rate_limit.search.reset.isoformat()
        }
    }