from functools import lru_cache
from datetime import datetime, timedelta

class Cache:
    def __init__(self):
        self._cache = {}
        self._expiry = {}

    def get(self, key):
        if key in self._cache and datetime.now() < self._expiry[key]:
            return self._cache[key]
        return None

    def set(self, key, value, expire_minutes=60):
        self._cache[key] = value
        self._expiry[key] = datetime.now() + timedelta(minutes=expire_minutes)