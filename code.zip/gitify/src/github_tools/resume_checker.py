from github import Github
from typing import Dict, List
from .config import GITHUB_TOKEN

class ResumeChecker:
    def __init__(self):
        self.github = Github(GITHUB_TOKEN)
    
    async def get_user_contributions(self, username: str, repo_name: str) -> Dict:
        try:
            repo = self.github.get_repo(repo_name)
            user_commits = repo.get_commits(author=username)
            
            pulls = repo.get_pulls(state='all', creator=username)
            
            issues = repo.get_issues(creator=username)
            
            contribution_summary = {
                "total_commits": user_commits.totalCount,
                "total_prs": pulls.totalCount,
                "total_issues": issues.totalCount,
                "recent_activity": self._get_recent_activity(user_commits, pulls, issues)
            }
            
            return contribution_summary
        
        except Exception as e:
            return {"error": str(e)}
    
    def _get_recent_activity(self, commits, pulls, issues, limit: int = 5) -> Dict[str, List]:
        return {
            "recent_commits": [
                {"message": commit.commit.message, "date": commit.commit.author.date.isoformat()}
                for commit in commits[:limit]
            ],
            "recent_prs": [
                {"title": pr.title, "state": pr.state, "url": pr.html_url}
                for pr in pulls[:limit]
            ],
            "recent_issues": [
                {"title": issue.title, "state": issue.state, "url": issue.html_url}
                for issue in issues[:limit]
            ]
        }