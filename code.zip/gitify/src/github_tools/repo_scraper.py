from github import Github
from typing import List, Dict
from .config import GITHUB_TOKEN

class RepositoryScraper:
    def __init__(self):
        self.github = Github(GITHUB_TOKEN)
    
    async def get_top_repositories(self, language: str = None, limit: int = 10) -> List[Dict]:
        query = "stars:>1000"
        if language:
            query += f" language:{language}"
            
        repositories = self.github.search_repositories(query=query, sort="stars", order="desc")
        
        results = []
        for repo in repositories[:limit]:
            results.append({
                "name": repo.full_name,
                "url": repo.html_url,
                "stars": repo.stargazers_count,
                "forks": repo.forks_count,
                "description": repo.description,
                "language": repo.language
            })
        
        return results