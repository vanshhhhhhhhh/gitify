from github import Github
from typing import List, Dict
from .config import GITHUB_TOKEN

class RepositoryFinder:
    def __init__(self):
        self.github = Github(GITHUB_TOKEN)
    
    async def find_repositories_by_tags(self, tags: List[str], limit: int = 10) -> List[Dict]:
        results = []
        
        for tag in tags:
            query = f"is:open label:\"{tag}\""
            issues = self.github.search_issues(query=query)
            
            for issue in issues[:limit]:
                repo = issue.repository
                
                if not issue.pull_requests:
                    results.append({
                        "repo_name": repo.full_name,
                        "issue_title": issue.title,
                        "issue_url": issue.html_url,
                        "labels": [label.name for label in issue.labels],
                        "created_at": issue.created_at.isoformat()
                    })
        
        return results[:limit]