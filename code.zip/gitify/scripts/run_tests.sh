#!/bin/bash

# Run tests for Gitify

# Activate virtual environment
source venv/bin/activate

# Run pytest
pytest src/tests