# Setup Instructions

1. **Clone the repository:**   ```bash
   git clone https://github.com/yourusername/gitify.git
   cd gitify   ```

2. **Create and activate a virtual environment:**   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate   ```

3. **Install dependencies:**   ```bash
   pip install -r requirements.txt   ```

4. **Create a `.env` file with your GitHub token:**   ```
   GITHUB_TOKEN=your_github_personal_access_token   ```

5. **Run the application:**   ```bash
   uvicorn src.main:app --reload   ```

6. **Access the API documentation:**
   Open `http://localhost:8000/docs` in your browser.