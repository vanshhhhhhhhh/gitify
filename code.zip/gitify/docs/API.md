# API Documentation

## Endpoints

### GET /top-repos/
Fetch top repositories based on stars.

#### Parameters
- `language`: Optional. Filter by programming language.
- `limit`: Optional. Number of repositories to return.

### GET /find-repos/
Find repositories by issue tags.

#### Parameters
- `tags`: List of tags to filter by.
- `limit`: Optional. Number of repositories to return.

### GET /check-contributions/{username}/{repo_name}
Check user contributions in a specific repository.

#### Parameters
- `username`: GitHub username.
- `repo_name`: Full repository name (e.g., `owner/repo`).