# Gitify

A collection of GitHub tools to make repository management and contribution easier.

## Features

- Repository Scraper: Find and analyze top GitHub repositories
- Tag-Based Repository Finder: Find repositories with specific tags and open issues
- Resume Checker: Analyze user contributions to specific repositories

## Setup

1. Clone the repository: