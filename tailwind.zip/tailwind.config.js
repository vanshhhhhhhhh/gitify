/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],

  content: ['./dist/*.html'],
  plugins: [require('tailwindcss-filters')],
  
} 

